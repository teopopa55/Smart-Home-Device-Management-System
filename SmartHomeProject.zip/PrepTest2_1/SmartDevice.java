package PrepTest2_1;

public abstract class SmartDevice {
    protected String deviceId;
    protected String roomName;

    public SmartDevice(String deviceId, String roomName) {
        this.deviceId = deviceId;
        this.roomName = roomName;
    }
    public abstract String getStatus();
    public  void connect()
    {
        if(deviceId==null || deviceId.isEmpty())
                throw new DeviceConnectionException("\nNo device id.");
        System.out.println("\nDevice: "+deviceId+"connecting...");
    }

}
