package PrepTest2_1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeManager {
    private List<SmartDevice> devices;
    private Map<String, SmartDevice> deviceLookup ;

    public HomeManager() {
         devices = new ArrayList<>();
         deviceLookup = new HashMap<>();
    }

    public void addDevice(SmartDevice d){
        devices.add(d);
        deviceLookup.put(d.deviceId, d);
    }
    public void showAllDevices()
    {
        for(SmartDevice s:devices)
        {
            System.out.println(s.getStatus());
        }
    }
    public void shutdownAll()
    {
        for(SmartDevice s:devices)
        {
            if(s instanceof Powerable)
                ((Powerable) s).turnOff();
        }
    }
    public SmartDevice findById(String id)
    {
        return deviceLookup.get(id);
    }

}
