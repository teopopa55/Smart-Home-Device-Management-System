package PrepTest2_1;

public class SmartLight extends SmartDevice implements Powerable{

    private int brightness;//0-100
    private boolean powerStatus;

    public SmartLight(String deviceId, String roomName) {
        super(deviceId, roomName);
        this.brightness =0;
        this.powerStatus = false;
    }

    @Override
    public String getStatus()
    {
        return "Light["+roomName+"] "+powerStatus+" ,Brightness: "+brightness+"%";
    }

    public void setBrightness(int level)
    {
            if(level<0 || level>100)
                throw new IllegalArgumentException("\nLevel of brightness is not between 0-100%.");
        brightness=level;
    }

    @Override
    public boolean isOn() {
        return powerStatus;
    }

    @Override
    public void turnOff() {
        System.out.println("\nSmartLine turning off...");
    }

    @Override
    public void turnOn() {
        System.out.println("\nSmartLine turning on...");
    }
}

