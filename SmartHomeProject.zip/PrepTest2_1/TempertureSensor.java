package PrepTest2_1;

public class TempertureSensor extends SmartDevice{
    private double currentTemp;

    public TempertureSensor(String deviceId, String roomName) {
        super(deviceId, roomName);
        this.currentTemp = currentTemp;
    }

    public String getStatus()
    {
        return "Sensor [Kitchen]: "+currentTemp+"°C";
    }

    public void updateTemp(double newTemp)
    {
        currentTemp=newTemp;
    }

}
