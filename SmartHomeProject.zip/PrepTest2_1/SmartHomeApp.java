package PrepTest2_1;


public class SmartHomeApp {
    public static void main (String[] args)
    {
        //1.
        HomeManager homeManager=new HomeManager();

        //2.
        try {
            SmartLight defect_light = new SmartLight("", "Salon");
            defect_light.connect();
        }catch(DeviceConnectionException e)
        {
            System.out.println("\nConnection failed."+e.getMessage());
        }

        //3.
        SmartLight bedroom_smartLight=new SmartLight("L1","Bedroom");
        TempertureSensor balcony_sensor= new TempertureSensor("T1","Balcony");
        homeManager.addDevice(bedroom_smartLight);
        homeManager.addDevice(balcony_sensor);

        //4.
        bedroom_smartLight.turnOn();
        bedroom_smartLight.setBrightness(75);
        balcony_sensor.updateTemp(15);

        System.out.println("\nAll Home Manager Devices are: ");
        homeManager.showAllDevices();

        //5.
        SmartDevice search= homeManager.findById("L1");
        if(search!=null)
        {
            System.out.println("\nDevice Found.");
            System.out.println(search.getStatus());
        }

        //6.
        homeManager.shutdownAll();

    }
}
