package PrepTest2_1;

public class DeviceConnectionException extends RuntimeException {
    public DeviceConnectionException(String message) {
        super(message);
    }
    public void printMessage()
    {
        System.out.println(getMessage());
    }

}
