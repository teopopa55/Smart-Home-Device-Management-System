package PrepTest2_1;

public interface Powerable {
   public void turnOn();
   public void turnOff();
   public boolean isOn();
}
